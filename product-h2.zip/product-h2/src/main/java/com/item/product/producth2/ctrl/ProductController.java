package com.item.product.producth2.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.item.product.producth2.model.Product;
import com.item.product.producth2.service.ProductService;

/**
 * @author bhardwaj.mukesh
 *
 */
@RestController
@RequestMapping("/api/product")
public class ProductController {

	@Autowired
	ProductService ProductService;

	@PostMapping("/name")
	public ResponseEntity<Product> saveByBrandName(@RequestBody Product product) {
		ProductService.saveByBrandName(product);

		return ResponseEntity.status(201).body(product);

	}

	@GetMapping("/{id}")
	public ResponseEntity<Product> fetchByBrandName(@PathVariable int id) {
		Product p = ProductService.getByBrandNameById(id);

		return ResponseEntity.status(200).body(p);

	}

	@GetMapping("/{price}")
	public ResponseEntity<Product> fetchByBrandPrice(@PathVariable int price) {
		Product p = ProductService.getByPrice(price);

		return ResponseEntity.status(200).body(p);

	}

	/*
	 * @PostMapping("/color") public Product saveByColorName(String colorname) {}
	 * 
	 * @PostMapping("/price") public Product saveByPrice(int price) {}
	 * 
	 * @PostMapping("/size") public Product saveByBrandSize(int size) {}
	 */

}
