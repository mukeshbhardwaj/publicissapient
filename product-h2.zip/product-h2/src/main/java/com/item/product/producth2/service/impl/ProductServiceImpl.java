package com.item.product.producth2.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.item.product.producth2.model.Product;
import com.item.product.producth2.repo.ProductRepo;
import com.item.product.producth2.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepo productRepo;

	@Override
	public Product saveByBrandName(Product name) {

		return productRepo.save(name);
	}
	

	@Override
	public Product getByBrandNameById(int id) {

		Optional<Product> p = productRepo.findById(id);
		if (p.isPresent()) {
			
			Product prod=p.get();
			return prod;
		} else {

			return null;
		}
	}

	
	@Override
	public Product getByPrice(int price) {

		Optional<Product> p = Optional.ofNullable(productRepo.findByPrice(price));
		if (p.isPresent()) {
			
			Product prod=p.get();
			return prod;
		} else {

			return null;
		}
	}
	@Override
	public Product saveByColorName(String colorname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product saveByPrice(int price) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product saveByBrandSize(int size) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Product getByColorName(String colorname) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Product getByBrandSize(int size) {
		// TODO Auto-generated method stub
		return null;
	}

}
