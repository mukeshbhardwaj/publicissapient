package com.item.product.producth2.service;

import org.springframework.stereotype.Service;

import com.item.product.producth2.model.Product;

/**
 * @author bhardwaj.mukesh
 *
 */
@Service
public interface ProductService {
	public Product saveByBrandName(Product name);

	public Product saveByColorName(String colorname);

	public Product saveByPrice(int price);

	public Product saveByBrandSize(int size);

	public Product getByBrandNameById(int id);

	public Product getByColorName(String colorname);

	public Product getByPrice(int price);

	public Product getByBrandSize(int size);

}
