package com.item.product.producth2.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.item.product.producth2.model.Product;

/**
 * @author bhardwaj.mukesh
 *
 */
public interface ProductRepo extends JpaRepository<Product, Integer> {
public Product findByPrice(int price);
	
}
