/*
 * package com.item.product.producth2.model;
 * 
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import javax.persistence.Entity; import javax.persistence.Id;
 * 
 *//**
	 * @author bhardwaj.mukesh
	 *
	 *//*
		 * @Entity public class Category {
		 * 
		 * @Id private int categoryId;
		 * 
		 * List<String> list =new ArrayList();
		 * 
		 * 
		 * }
		 */