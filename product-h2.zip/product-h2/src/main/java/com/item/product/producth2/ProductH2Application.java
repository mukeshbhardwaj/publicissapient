package com.item.product.producth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = { "com.item.product.producth2.service.imp", "com.item.product.producth2.repo",
		"com.item.product.producth2.model", "com.item.product.producth2.ctrl","com.item.product.producth2.service" })
public class ProductH2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductH2Application.class, args);
	}

}
