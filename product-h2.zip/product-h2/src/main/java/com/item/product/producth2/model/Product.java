package com.item.product.producth2.model;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * @author bhardwaj.mukesh
 *
 */
@Entity
public class Product {
	@Id
	private int productId;
	private String productBrand;
	private int productPrice;
	private String productColor;
	private int productSize;
//	private Category category;

	public Product() {
	}

	public Product(int productId, String productBrand, int productPrice, String productColor, int productSize) {
		super();
		this.productId = productId;
		this.productBrand = productBrand;
		this.productPrice = productPrice;
		this.productColor = productColor;
		this.productSize = productSize;
	}

//	insert into PRODUCT values(200,'puma','red',1000,32);
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductColor() {
		return productColor;
	}

	public void setProductColor(String productColor) {
		this.productColor = productColor;
	}

	public int getProductSize() {
		return productSize;
	}

	public void setProductSize(int productSize) {
		this.productSize = productSize;
	}

}
